import os
from PIL import Image, ExifTags
import cv2
import numpy as np
from scipy.fftpack import fft2, fftshift

# Method 1: Check EXIF Metadata
def check_exif_metadata(image_path):
    """Check for EXIF metadata in the image."""
    try:
        image = Image.open(image_path)
        exif_data = image._getexif()
        if exif_data is None:
            return "No EXIF metadata found (likely AI-generated)"
        return "EXIF metadata found (likely Natural)"
    except Exception as e:
        return f"Error reading EXIF metadata: {e}"

# Method 2: Analyze Image Noise Using FFT
def analyze_image_noise(image_path):
    """Analyze the frequency domain (FFT) of the image to detect AI-like noise patterns."""
    try:
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        fft = fft2(image)
        fft_shift = fftshift(fft)
        
        # Avoid log(0) issue by clipping values
        magnitude_spectrum = 20 * np.log(np.clip(np.abs(fft_shift), 1e-10, None))
        
        # Calculate the amount of high-frequency noise
        noise_level = np.mean(magnitude_spectrum)
        if noise_level > 200:
            return f"High Noise Detected (level: {noise_level:.2f}), likely AI-generated"
        return f"Low Noise Detected (level: {noise_level:.2f}), likely Natural"
    except Exception as e:
        return f"Error analyzing noise: {e}"

# Method 3: Analyze Color Distribution
def analyze_color_distribution(image_path):
    """Analyze the color distribution of the image to look for AI-generated patterns."""
    try:
        image = Image.open(image_path)
        image = image.convert('RGB')
        image_array = np.array(image)

        hist_r = cv2.calcHist([image_array], [0], None, [256], [0, 256])
        hist_g = cv2.calcHist([image_array], [1], None, [256], [0, 256])
        hist_b = cv2.calcHist([image_array], [2], None, [256], [0, 256])

        mean_r = np.mean(hist_r)
        mean_g = np.mean(hist_g)
        mean_b = np.mean(hist_b)

        if mean_r > 100 and mean_g > 100 and mean_b > 100:
            return "Unusual color distribution detected, likely AI-generated"
        return "Natural color distribution detected"
    except Exception as e:
        return f"Error analyzing color distribution: {e}"

# Main detection function
def detect_ai_image(image_path):
    """Run all detection methods to determine if the image is AI-generated or natural."""
    exif_result = check_exif_metadata(image_path)
    noise_result = analyze_image_noise(image_path)
    color_result = analyze_color_distribution(image_path)

    results = [exif_result, noise_result, color_result]
    ai_signals = sum([1 if 'AI-generated' in r else 0 for r in results])

    if ai_signals >= 2:
        return "AI-Generated"
    return "Natural"
