from googleapiclient.discovery import build

# Google API Key and Search Engine ID
GOOGLE_API_KEY = "YOUR_GOOGLE_API_KEY"
SEARCH_ENGINE_ID = "YOUR_SEARCH_ENGINE_ID"

def google_image_search(query):
    """
    Search for images on Google Custom Search API.

    Args:
        query (str): The search query string.

    Returns:
        list: A list of URLs of top image results.
    """
    try:
        service = build("customsearch", "v1", developerKey=GOOGLE_API_KEY)
        results = service.cse().list(
            q=query,             # Query string
            cx=SEARCH_ENGINE_ID, # Search Engine ID
            searchType="image",  # Restrict to image search
            num=5                # Number of results to return
        ).execute()

        # Extract URLs of images
        image_urls = [item["link"] for item in results.get("items", [])]
        return image_urls
    except Exception as e:
        print(f"Google API Error: {e}")
        return []
