import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, render_template, redirect, flash
from werkzeug.utils import secure_filename
from ai_detection import detect_ai_image

# Initialize Flask app
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.secret_key = 'your_secret_key'

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    """Check if the uploaded file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def home():
    """Render the homepage."""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_images():
    """Handle multiple image uploads and run AI detection on each image."""
    if 'images' not in request.files:
        flash('No files uploaded!')
        return redirect(request.url)

    files = request.files.getlist('images')

    if not files:
        flash('No files selected!')
        return redirect(request.url)

    results = []  # List to store the results of each image
    for file in files:
        if file and allowed_file(file.filename):
            # Save the uploaded file
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Detect if the image is AI-generated
            result = detect_ai_image(filepath)
            results.append({'filename': filename, 'result': result})
        else:
            results.append({'filename': file.filename, 'result': 'Invalid file format'})

    # Pass the results to the template to display them
    return render_template('index.html', results=results)

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)
