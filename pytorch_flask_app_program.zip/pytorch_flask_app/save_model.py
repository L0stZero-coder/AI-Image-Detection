import torch
import torch.nn as nn

# Define your model architecture
class YourModelClass(nn.Module):
    def __init__(self):
        super(YourModelClass, self).__init__()
        # Define layers (example: adjust as needed for your model)
        self.fc = nn.Linear(224 * 224 * 3, 2)

    def forward(self, x):
        return self.fc(x)

# Instantiate the model
model = YourModelClass()

# (Optional) Train your model or load existing weights if needed
# Example: Simulate training by randomizing weights
for param in model.parameters():
    param.data = torch.randn_like(param)

# Save the model's state_dict (weights)
torch.save(model.state_dict(), 'ai_detection_model.pth')

print("Model saved successfully as 'ai_detection_model.pth'")
 
